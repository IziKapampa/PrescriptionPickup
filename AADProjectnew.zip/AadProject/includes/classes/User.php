<?php  

class User {
	private $con;
	private $user;

	//Constructor
	public function __construct($con, $user){
		$this->con = $con;
		$user_details = mysqli_query($con, "SELECT * from pharmacist WHERE email='$user'");
		$this->user = mysqli_fetch_array($user_details);
	}

	//Getting the email of the user
	public function getUser(){
		return $this->user['email'];
	}

	 //The less we select, the faster it will generate results
	public function getFirstAndLastName() {
		$email = $this->user['email'];
		$query = mysqli_query($this->con, "SELECT first_name, last_name FROM pharmacist WHERE email='$email'"); 
		$row = mysqli_fetch_array($query);
		//Returning first and last name connected together
		return $row['first_name'] . " " . $row['last_name'];
	}

	public function getPharmacists() {
		$email = $this->user['email'];
		$query = mysqli_query($this->con, "SELECT * FROM pharmacist WHERE email='$email'");
		$row = mysqli_fetch_array($query);
		$num_pharmacists = mysqli_num_rows($query);

		if(mysqli_num_rows($query) == 0){
			echo "<h1>There are no pharmacist registered within the database<br></h1>";
		}
		else if(mysqli_num_rows($query) == 1){
			echo "<div class='pharmacist_number'><h3>$num_pharmacist registered pharmacist</h3>
				</div>";
		}
		else {
			echo "<div class='pharmacist_number'><h3>$num_pharmacist registered pharmacists</h3>
				</div>";
		}

		foreach ($query as $row){
			echo "
			<div class='result'>
				


			"
		}

	}

}









?>