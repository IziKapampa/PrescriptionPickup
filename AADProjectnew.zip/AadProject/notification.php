<?php 
include("includes/header.php");
$error_array = array();

$isAdmin = $pharmacist['admin'];

//if the user is an administrator, show them the Admin Control Panel icon
if($isAdmin == 'yes'){
	echo '<nav>
	<a href="#">
				<?php echo $pharmacist["first_name"] . " " . $pharmacist["last_name"]; ?>
			</a>
			<a href="pharmacist.php">
		<i class="fas fa-home fa-2x"></i>
		</a>	
	 <a href="admin.php">
	  	<i class="fas fa-user-shield fa-2x"></i>
	  </a>			
	  <a href="includes/handlers/logout.php">
		<i class="fas fa-power-off fa-2x"></i>
	  </a>
</nav>';
}
//if the user is not an administrator, hide the Admin Control Panel icon
else {
	echo '<nav>
	<a href="#">
				<?php echo $pharmacist["first_name"] . " " . $pharmacist["last_name"]; ?>
			</a>
		 <a href="pharmacist.php">
		<i class="fas fa-home fa-2x"></i>
	</a>			
	  <a href="includes/handlers/logout.php">
		<i class="fas fa-power-off fa-2x"></i>
	  </a>	
</nav>';

}


?>



<div class='notification'>
		
		<div class='top_head'>
			<h4>Showcasing how patient notifications would look in practical scenarios<br><br></h4>
		</div>
		<div class="patient_email">
			<form action="notification.php" method="POST">
                <label>Email</label>
                <input type="email" name="email" required="required"/>
                <input type="submit" name="patient" value="Verify">
            </form>    
        </div>
        <div class="patient_body">

		<?php 
		if(isset($_POST['patient'])){
			$email = $_POST['email'];

			$query = mysqli_query($con, "SELECT * FROM patient WHERE email='$email'");
			$row = mysqli_fetch_array($query);
			$pid = $row['id'];
			$num_rows = mysqli_num_rows($query);

			if($num_rows < 1){
				echo"<script>alert('Email does not exist!')</script>";
			}
			else {
				$patient_query = mysqli_query($con, "SELECT * FROM prescriptions WHERE patient_id='$pid'");
				$patient_array = mysqli_fetch_array($patient_query);
				$patient_rows = mysqli_num_rows($patient_query);

				$blood_test_query = mysqli_query($con, "SELECT * FROM blood_test_schedule WHERE patient_id='$pid'");
				$blood_test_array = mysqli_fetch_array($blood_test_query);
				$blood_rows = mysqli_num_rows($blood_test_query);

				$patientid = $row['id'];
				$first_name = $row['first_name'];
				$last_name = $row['last_name'];
				$email2 = $row['email'];
				$age = $row['age']; 
				$gender = $row['gender'];
				$blood = $row['blood_type'];
						
     					
     				



				if($patient_rows > 0){

					echo "<h5><center>Patient Details</center></h5>";
					?>
						<table class='notification-table'>
	 					<thead>	
    					<tr>
     					<th>ID</th>
     					<th>Name</th>
     					<th>Email</th>
     					<th>Age</th>
     					<th>Gender</th>
     					<th>BloodType</th>
    					</tr>
    					<tbody>
    					<tr>
						<td><?=$patientid?></td>
     					<td><?=$first_name. ' ' .$last_name?></td>
     					<td><?=$email2?></td>
     					<td><?=$age?></td>
     					<td><?=$gender?></td>
     					<td><?=$blood?></td>
     					</tr>
     					</tbody></table>
    					</thead>
     				<?php

     				}


     				
     				echo "<h5><center>Prescriptions Details</center></h5>";
     				?>
     				<table class='notification-table'>
	 					<thead>	
    					<tr>
     					<th>Patient ID</th>
     					<th>Medication</th>
     					<th>Monthly Repeat(s)</th>
    					</tr>
    					</thead>

    				<?php foreach($patient_query as $patient_array){ 
    				$medication_name = $patient_array['medication_id'];
     				$medication_query = mysqli_query($con, "SELECT * FROM medication WHERE ID='$medication_name'");
     				$medication_row = mysqli_fetch_array($medication_query);
	
    				 $medicine = $medication_row['MEDICATION'];
     				 $repeat = $patient_array['repeat_prescription'];
    					?>	
    					<tbody>
    					<tr>
						<td><?=$patientid?></td>
     					<td><?=$medicine?></td>
     					<td><?=$repeat?></td>
     					</tr>
     					
     					


     				<?php
     				} ?>
     				</tbody></table>
     				<?php
					if($blood_rows > 0){
						echo "<h5><center>BloodTests Schedule</center></h5>";
						?>
						<table class='notification-table'>
	 					<thead>	
    					<tr>
     					<th>Patient ID</th>
     					<th>Blood Test</th>
     					<th>Date</th>
     					<th>Time</th>
    					</tr>
    					</thead>
    					<tbody>
    					<?php 	
    					foreach($blood_test_query as $blood_test_array){
    						$bloodtest = $blood_test_array['test'];
							$date = $blood_test_array['appointment_date'];
							$time = $blood_test_array['appointment_time'];

    					?>
    					<tr>
						<td><?=$patientid?></td>
     					<td><?=$bloodtest?></td>
     					<td><?=$date?></td>
     					<td><?=$time?></td>
     					</tr>
     					<?php } ?>
     					</tbody></table>

						<?php
					}

				}
				
			}


		


?>


        </div>


</div>

