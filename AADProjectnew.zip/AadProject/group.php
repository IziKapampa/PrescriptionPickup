<?php 
include("includes/header.php");

//If the user is not an administrator, send them back to the login page
$query = mysqli_query($con, "SELECT * FROM pharmacist WHERE email='$pharmacistLoggedIn'");
$row = mysqli_fetch_array($query);

$isAdmin = $row['admin'];

if($isAdmin == 'no'){
	header("Location: includes/handlers/logout.php");
}


?>

<!--Navigation bar-->
<nav>
	<a href="#">
				<?php echo $pharmacist['first_name'] . " " . $pharmacist['last_name']; ?>
	</a>
	 <a href="admin.php">	
	  	<i class="fas fa-user-shield fa-2x"></i>
	  </a>	
	<a href='pharmacist.php'>
		<i class="fas fa-home fa-2x"></i>
	</a>	
	<a href="includes/handlers/logout.php">
		<i class="fas fa-power-off fa-2x"></i>
	</a>	


</nav>

<div class='results' id='results'>

	 <table class='styled-table'>
	 	<thead>	
    		<tr>
     			<th>ID</th>
     			<th>Name</th>
     			<th>Email</th>
     			<th>Admin</th>
    		</tr>
    	</thead>		

	<?php 
		$query = mysqli_query($con, "SELECT * FROM pharmacist WHERE email!='$pharmacistLoggedIn' ORDER BY staff_id ASC");
		$row = mysqli_fetch_array($query);
		$num_pharmacists = mysqli_num_rows($query);
		if(mysqli_num_rows($query) == 0){
			echo "<h1><span style='color:black;'>There are no pharmacists registered within the database<br></span></h1>";
		}
		else if(mysqli_num_rows($query) == 1){
			echo "<div class='pharmacist_number'><h3><span style='color:black;'>$num_pharmacists registered pharmacist</span></h3>
				</div>";
		}
		else {
			echo "<div class='pharmacist_number'><h3><span style='color:black;'>$num_pharmacists registered pharmacists</span></h3>
				</div>";
		}
		?>
		<tbody>
		<?php
		foreach ($query as $row){
			$staffid = $row['staff_id'];
			$first_name = $row['first_name'];
			$last_name = $row['last_name'];
			$email2 = $row['email'];
			$admin = $row['admin']; ?>
			
				
				<tr>
				<td><?=$staffid?></td>
     			<td><?=$first_name. " " .$last_name?></td>
     			<td><?=$email2?></td>
     			<td><?=$admin?></td>
     			</tr>
			
			
	<?php	}  ?>
			</tbody>
     		</table>

	</div>