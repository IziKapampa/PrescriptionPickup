<?php 
include("includes/header.php");

//If the user is not an administrator, send them back to the login page
$query = mysqli_query($con, "SELECT * FROM pharmacist WHERE email='$pharmacistLoggedIn'");
$row = mysqli_fetch_array($query);


$isAdmin = $row['admin'];

//if the user is an administrator, show them the Admin Control Panel icon
if($isAdmin == 'yes'){
	echo '<nav>
			<a href="pharmacist.php">
		<i class="fas fa-home fa-2x"></i>
		</a>	
	 <a href="admin.php">
	  	<i class="fas fa-user-shield fa-2x"></i>
	  </a>			
	  <a href="includes/handlers/logout.php">
		<i class="fas fa-power-off fa-2x"></i>
	  </a>
</nav>';
}
//if the user is not an administrator, hide the Admin Control Panel icon
else {
	echo '<nav>
	<a href="#">
				<?php echo $row["first_name"] . " " . $row["last_name"]; ?>
			</a>
		 <a href="pharmacist.php">
		<i class="fas fa-home fa-2x"></i>
	</a>			
	  <a href="includes/handlers/logout.php">
		<i class="fas fa-power-off fa-2x"></i>
	  </a>	
</nav>';

}



?>

<body>
	<div class="container" style="position: relative; top: 100px; width: 1000px; height: 800px; overflow-y: scroll;">
		<div class="content">
				<div id="myModal2" class="modal">
					<div class="modal-content">
					    <div class="modal-header">
					    	<span style="display: none;" class="close">&times;</span>
					    	<h1>TEST</h1>
					    </div>
					</div>
				</div>
				<div id="myModal" class="modal">
					<div class="modal-content">
					    <div class="modal-header">
					      <span style="display: none;" class="close">&times;</span>
					      <h2>Schedule blood work exam</h2>
					    </div>
					    <div class="modal-body">
					      <form method="POST">
					      	<input id="user" type="email" name="email" placeholder="Enter email">
					      	<label for="a_date">Preferred date</label>
					      	<label for="exam">Test</label>
					      	<select id="exam" name="bloodTest">
					      		<option value="" disabled selected>Select blood test</option>
					      		<?php 
					      			$query = mysqli_query($con, "SELECT ELEMENT_NAME FROM blood_tests");
					      			$results = mysqli_fetch_array($query);
					      			while ($row = $query->fetch_assoc()) {
					      				echo "<option value=\"{$row['ELEMENT_NAME']}\">{$row['ELEMENT_NAME']}</option>";
					      			}
					      		?>
					      	</select>
					      	<input id="a_date" type="date" name="appointmentDate">
					      	<label for="a_time">Appointment time</label>
					      	<input id="a_time" type="time" name="appointmentTime">
					      	<button type="submit" name="bookSchedule">Schedule</button>
					      </form>
					    </div>
					    <div class="modal-footer">
					      <h3>Noobs</h3>
					    </div>
					  </div>
			</div>
			<h1 style="text-align: center; font-size: 28px;">VIEW PRESCRIPTIONS & SCHEDULES</h1>
			<div class="prescribe">
				<h1 style="text-align: left; font-size: 22px; padding: 10px; color: #222;">
					All prescriptions
				</h1>
				<div>
					<table style="border-collapse: collapse; width: 100%; font-size: 20px; text-align: left;">
						<tr>
							<th style="background-color: #588c7e;">ID</th>
							<th style="background-color: #588c7e;">Medication</th>
							<th style="background-color: #588c7e;">Email</th>
							<th style="background-color: #588c7e;">Prescription</th>
						</tr>
						<?php
							$query = mysqli_query($con,"SELECT prescription_id,medication.MEDICATION,patient.email,repeat_prescription FROM prescriptions INNER JOIN medication on medication.ID = prescriptions.medication_id INNER JOIN patient ON patient.id = prescriptions.patient_id WHERE patient.id = prescriptions.patient_id");
							if (mysqli_num_rows($query) > 0){
								while ($row = $query->fetch_assoc()) {
									echo "<tr><td>".$row['prescription_id']."</td><td>".$row['MEDICATION']."</td><td>".$row['email']."</td><td>".$row['repeat_prescription']."</td></tr>";
								}
							}
						?>
					</table>
				</div>
			</div>
			<div style="padding: 50px; margin-right: 20px;">
				<a style="font-size: 24px; border-radius: 5px; background-color: #588c7e; color: black; padding: 20px;" href="pickup.php">Create prescription</a>
			</div>
			<div class="prescribe">
				<h1 style="text-align: left; font-size: 22px; padding: 10px; color: #222;">
					All blood test schedules
				</h1>
				<div>
					<table style="border-collapse: collapse; font-size: 20px; width: 100%; text-align: left;">
						<tr>
							<th style="background-color: #588c7e;">ID</th>
							<th style="background-color: #588c7e;">Firstname</th>
							<th style="background-color: #588c7e;">Lastname</th>
							<th style="background-color: #588c7e;">Blood Test</th>
							<th style="background-color: #588c7e;">DATE</th>
							<th style="background-color: #588c7e;">TIME</th>
						</tr>
						<?php
							$query = mysqli_query($con,"SELECT blood_test_schedule.blood_work_id,patient.first_name,patient.last_name,blood_test_schedule.test,blood_test_schedule.appointment_date,blood_test_schedule.appointment_time FROM blood_test_schedule INNER JOIN patient ON patient.id = blood_test_schedule.patient_id ");
							if (mysqli_num_rows($query) > 0){
								while ($row = $query->fetch_assoc()) {
									echo "<tr><td>".$row['blood_work_id']."</td><td>".$row['first_name']."</td><td>".$row['last_name']."</td><td>".$row['test']."</td><td>".$row['appointment_date']."</td><td>".$row['appointment_time']."</td></tr>";
								}
							}
						?>
					</table>
				</div>
				<button id="book" style="font-size: 24px; margin-top: 30px; border-radius:  5px; margin-bottom: 100px; background-color: #588c7e; color: black; padding: 20px; border: none;">Book schedule</button>
			</div>
			<br><br><br><br>
		</div>
	</div>
</body>


<script type="text/javascript">
	function displayBloodWork($bloodWork){
		if ($bloodWork){
			document.getElementById("blood").innerHTML = "Exam: " + $bloodWork;
			document.getElementById("book").style.display = 'block';
			document.getElementById("create").style.display = 'block';
			document.getElementById("exam").value = $bloodWork;
		}
	}

	function getRestrictionLevel() {
		var value = document.getElementById("medication").value;
		var select = document.getElementById("restrictions");
		select.innerHTML = "";	
		var restriction = parseInt(value[0]);
		for (var i = 0; i < restriction; i++){
			var option = document.createElement("option");
			var number = (i+1).toString();
		   	option.text = number;
		   	select.add(option);
		}
	}
	
	var modal = document.getElementById("myModal");

	var span = document.getElementsByClassName("close")[0];

	var button = document.getElementById("book");

	button.onclick = function() {
	 	modal.style.display = "block";
	}

	span.onclick = function() {
		modal.style.display = "none";
	}

	window.onclick = function(event) {
	  	if (event.target == modal) {
			modal.style.display = "none";
		}
	}

</script>



<?php

// if (isset($_POST['bookSchedule']))
// {
// 	$email = $_POST['email'];
// 	$blood = $_POST['bloodTest'];
// 	$appointmentDate = $_POST['appointmentDate'];
// 	$appointmentTime = $_POST['appointmentTime'];

// 	$query = "SELECT id FROM patient WHERE email='$email';";
// 	$select = mysqli_query($con,$query);
// 	$results = mysqli_fetch_array($select);

// 	$query = "INSERT INTO blood_test_schedule (blood_work_id,patient_id,test,appointment_date,appointment_time) VALUES (null,".$results['id'].",'".$blood."','".$appointmentDate."','".$appointmentTime."');";

// 	mysqli_query($con,$query);
// }

if (isset($_POST['bookSchedule']))
{
	$email = $_POST['email'];
	$blood = $_POST['bloodTest'];
	$appointmentDate = $_POST['appointmentDate'];
	$appointmentTime = $_POST['appointmentTime'];

	$query = "SELECT id FROM patient WHERE email='$email';";
	$select = mysqli_query($con,$query);
	$userId = mysqli_fetch_array($select);
	$patientid = $userId['id'];

	$blood_query = "SELECT appointment_date,appointment_time,test FROM blood_test_schedule WHERE patient_id='$patientid';";
	$blood_select = mysqli_query($con,$blood_query);
	$results = mysqli_fetch_array($blood_select);
	$bloodtest_type = $results['test'];	

	$date = date('Y-m-d');

	if ($appointmentDate > $date){
		if ($bloodtest_type == $blood){
			echo "<script>alert('The patient has a pre-booked appointment for the said bloodtest'); </script>";
			echo "<script>
			document.getElementById('exam').value = '$blood'; 
			document.getElementById('user').value = '$email';
			</script>";
			echo "<script>$('#book').click();</script>";
		}
		else if ($bloodtest_type != $blood){
			$query = "INSERT INTO blood_test_schedule VALUES ('','$patientid','$blood','$appointmentDate','$appointmentTime');";
			$run = mysqli_query($con,$query);	
			echo "<script>alert('appointment scheduled successfully!')</script>";
		}
	}
	else{
		echo "<script>alert('Failed. Date must be bigger than today')</script>";
	}

}


function pickDate($results){
	for ($i = 0; $i < $results.length; $i++){
		echo "string";
	}
}

function sendNotification($userId){
	require_once("includes/PHPMailer-5.2-stable/PHPMailerAutoload.php");
	$mail = new PHPMailer();
	$mail->isSMTP();
	$mail->SMTAuth = true;
	$mail->SMTPSecure = 'ssl';
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 465;
	$mail->isHTML();
	$mail->username = "scott.izidore@gmail.com";
	$mail->password = "";
	$mail->SetFrom('noReply@howcode.org');
	$mail->subject = "Notification";
	$mail->body = "Blood test schedule";
	$mail->Send();
}




?>