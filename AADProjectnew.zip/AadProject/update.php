<?php
include("includes/header.php");
require_once("config/config.php");

$isAdmin = $pharmacist['admin'];
if($isAdmin == 'no'){
  header("Location: includes/handlers/logout.php");
}


$error_array = array();
$success_array = array();


 if(isset($_POST['add'])){
    $staff = rand(0,1000);
    
    $is_valid = mysqli_query($con, "SELECT * FROM pharmacist WHERE staff_id='$staff'");
    $number_rows = mysqli_num_rows($is_valid);

    while(true){
      if($number_rows > 0){
        $staff = rand(0,1000);
     }
     else {
      break;
     }
    }
    $firstname = $_POST['firstname'];
    $firstname = strip_tags($_POST['firstname']); // Remove html tags
    $firstname = str_replace(' ', '', $firstname); // Security check for spaces - removes spaces
    $firstname = ucfirst(strtolower($firstname)); // Uppercase first letter - lowercase the rest
    
    $lastname = $_POST['lastname'];
    $lastname = strip_tags($_POST['lastname']); // Remove html tags
    $lastname = str_replace(' ', '', $lastname); // Security check for spaces - removes spaces
    $lastname = ucfirst(strtolower($lastname)); // Uppercase first letter - lowercase the rest

    $email = $_POST['email'];
    $email = strip_tags($_POST['email']); // Remove html tags
    $email = str_replace(' ', '', $email); // Security check for spaces - removes spaces

    $password = $_POST['password'];
    if(strlen($password) > 30 || strlen($password) < 5) array_push($error_array, "<b><span style='color: #FF0000;'>ALERT: Password can only be between 5 & 30 characters.</span></b>");

    if(preg_match('/[^A-Za-z0-9]/', $password)) array_push($error_array, "<b><span style='color: #FF0000;'>ALERT: Password can only contain english & numerical values.</span></b>");
    

    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    if(!empty($_POST['admin'])){
      $admin = 'yes';
    }
    else{
      $admin = 'no';  
    }

    if(strlen($firstname) > 25 || strlen($firstname) < 2) array_push($error_array, "<b><span style='color: #FF0000;'>ALERT: First name must be between 2 & 25 characters.</span></b>");

    if(strlen($lastname) > 25 || strlen($lastname) < 2) array_push($error_array, "<b><span style='color: #FF0000;'>ALERT: Last name must be between 2 & 25 characters.</span></b>");


    // Checks if emails are in valid format
    if(filter_var($email, FILTER_VALIDATE_EMAIL)){
      $email = filter_var($email, FILTER_VALIDATE_EMAIL);

    $query = mysqli_query($con, "SELECT * FROM pharmacist WHERE email='$email'");
    $rows = mysqli_num_rows($query);
    }
    else{ 
      array_push($error_array,"<b><span style='color: #FF0000;'>ALERT: Invalid email format</span></b><br>");
    }
    
 
    if($rows > 0){
      //echo '<script>alert("This email is already registered under another pharmacist")</script>';
      array_push($error_array, "<b><span style='color: #FF0000;'>ALERT: This email is currently in use.</span></b><br>");
    }
    
    if(empty($error_array)){
    array_push($success_array, "<b><span style='color: #51B400;'>ALERT: User registered sucessfully!</span></b><br>");
    $insert = mysqli_query($con, "INSERT INTO pharmacist VALUES('', '$staff', '$firstname', '$lastname', '$email', '$password', '$admin')");  
  }
  //header("Location: admin.php");

}

if(isset($_POST['apply'])){
  $email = $_POST['email2'];
  $id = $_POST['staffid'];
  $query = mysqli_query($con, "SELECT * FROM pharmacist WHERE email='$email'");
  $rows = mysqli_num_rows($query);

  if($rows == 0){
    array_push($error_array, "<b><span style='color: #FF0000;'>ALERT: There are no pharmacists registered under such credentials.</span></b><br>");
  }
  
  if(empty($error_array)){
    $delete = mysqli_query($con, "DELETE FROM pharmacist WHERE email='$email' AND staff_id='$id'");
    array_push($success_array, "<b><span style='color: #51B400;'>ALERT: User has been deleted successfully!</span></b><br>");
  }

  

  }



?>


