<?php 
include("includes/header.php");


header("Location: pharmacist.php");
	

?>