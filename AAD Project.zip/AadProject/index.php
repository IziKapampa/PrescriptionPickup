<?php 
include("includes/header.php");



	echo "Test message";

?>