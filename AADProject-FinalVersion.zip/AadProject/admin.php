<?php 
include("includes/header.php");
include ("update.php");
error_reporting(E_ALL);
ini_set('display_errors', '1');

//If the user is not an administrator, send them back to the login page
$query = mysqli_query($con, "SELECT * FROM pharmacist WHERE email='$pharmacistLoggedIn'");
$row = mysqli_fetch_array($query);

$isAdmin = $row['admin'];

if($isAdmin == 'no'){
	header("Location: register.php");
	exit();
}


?>

<!--Navigation bar-->
<nav>
	<a href="#">
				<?php echo $pharmacist['first_name'] . " " . $pharmacist['last_name']; ?>
	</a>
	<a href='pharmacist.php'>
		<i class="fas fa-home fa-2x"></i>
	</a>	
	<a href="includes/handlers/logout.php">
		<i class="fas fa-power-off fa-2x"></i>
	</a>	


</nav>




<!--Container that holds admin functionality buttons -->
<div class='container'>
	<div class='content'>
		<h1>Admin Control Panel</h1>
		<ul>
			<button type="button" id='add_btn' class="btn btn-success" data-toggle="modal" data-target="#form_modal"><span class="glyphicon glyphicon-plus"></span> Add A Pharmacist</button>
			<button type="button" id='delete_btn' class="btn btn-success" data-toggle="modal" data-target="#delete_modal"><span class="glyphicon glyphicon-plus"></span>Remove A Pharmacist</button>
			<li><a href="group.php">View Pharmacists</a></li>
		</ul>
		<?php 
                if(in_array("<b><span style='color: #FF0000;'>ALERT: This email is currently in use.</span></b><br>", $error_array)) echo "<b><span style='color: #FF0000;'>ALERT: This email is currently in use.</span></b><br>";
                else if(in_array("<b><span style='color: #FF0000;'>ALERT: There are no pharmacists registered under such credentials.</span></b><br>", $error_array)) echo "<b><span style='color: #FF0000;'>ALERT: There are no pharmacists registered under such credentials.</span></b><br>";
                else if(in_array("<b><span style='color: #FF0000;'>ALERT: First name must be between 2 & 25 characters.</span></b>", $error_array)) echo "<b><span style='color: #FF0000;'>ALERT: First name must be between 2 & 25 characters.</span></b>";
                else if(in_array("<b><span style='color: #FF0000;'>ALERT: Last name must be between 2 & 25 characters.</span></b>", $error_array)) echo "<b><span style='color: #FF0000;'>ALERT: Last name must be between 2 & 25 characters.</span></b>";
                else if(in_array("<b><span style='color: #FF0000;'>ALERT: Password can only be between 5 & 30 characters.</span></b>", $error_array)) echo "<b><span style='color: #FF0000;'>ALERT: Password can only be between 5 & 30 characters.</span></b>";
                else if(in_array("<b><span style='color: #FF0000;'>ALERT: Password can only contain english & numerical values.</span></b>", $error_array)) echo "<b><span style='color: #FF0000;'>ALERT: Password can only contain english & numerical values.</span></b>";	
                else if(in_array("<b><span style='color: #FF0000;'>ALERT: Invalid email format</span></b><br>", $error_array)) echo "<b><span style='color: #FF0000;'>ALERT: Invalid email format</span></b><br>";
                else if(in_array("<b><span style='color: #51B400;'>ALERT: User registered sucessfully!</span></b><br>", $success_array)) echo "<b><span style='color: #51B400;'>ALERT: User registered sucessfully!</span></b><br>";
                else if(in_array("<b><span style='color: #51B400;'>ALERT: User has been deleted successfully!</span></b><br>", $success_array)) echo "<b><span style='color: #51B400;'>ALERT: User has been deleted successfully!</span></b><br>";
                ?>
	</div>
</div>

  <div class="modal fade" id="form_modal" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form method="POST" action="admin.php">
          <div class="modal-header">
            <h5 class="modal-title">New Pharmacist Credentials</h5>
          </div>
          <div class="modal-body">
            <div class="col-md-2"></div>
            <div class="col-md-8">
              <div class="form-group">
                <label>First Name</label>
                <input type="text" name="firstname" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label>Last Name</label>
                <input type="text" name="lastname" class="form-control" required="required" />
              </div>
              <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label>New Password</label>
                <input type="password" name="password" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label>Admin</label>
                <input type="checkbox" name="admin" class="form-control"/>
              </div>
            </div>
          </div>
          <div style="clear:both;"></div>
          <div class="modal-footer">
            <button name="add" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span>Add</button>
            <button class="btn btn-danger" type="button" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>Close</button>
          </div>
          </div>
        </form>
    	</div>
        </div>
    	</div>

    	<!--DELETE PHARMACIST -->


 <div class="modal fade" id="delete_modal" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <form method="POST" action="admin.php">
          <div class="modal-header">
            <h5 class="modal-title">Revoke Pharmacist Credentials</h5>
          </div>
          <div class="modal-body">
            <div class="col-md-2"></div>
            <div class="col-md-8">
              <div class="form-group">
                <label>Staff ID</label>
                <input type="text" name="staffid" class="form-control" required="required"/>
              </div>
              <div class="form-group">
                <label>Staff Email</label>
                <input type="email" name="email2" class="form-control" required="required" />
              </div>
            </div>
          </div>
          <div style="clear:both;"></div>
          <div class="modal-footer">
            <button name="apply" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span>Apply</button>
            <button class="btn btn-danger" type="button" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>Cancel</button>
          </div>
          </div>
        </form>
    	</div>
        </div>
    	</div>
