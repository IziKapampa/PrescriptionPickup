<?php 
include("includes/header.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$isAdmin = $pharmacist['admin'];

//if the user is an administrator, show them the Admin Control Panel icon
if($isAdmin == 'yes'){
	echo '<nav>
	<a href="#">
				<?php echo $pharmacist["first_name"] . " " . $pharmacist["last_name"]; ?>
			</a>
			<a href="pharmacist.php">
		<i class="fas fa-home fa-2x"></i>
		</a>	
	 <a href="admin.php">
	  	<i class="fas fa-user-shield fa-2x"></i>
	  </a>			
	  <a href="includes/handlers/logout.php">
		<i class="fas fa-power-off fa-2x"></i>
	  </a>
</nav>';
}
//if the user is not an administrator, hide the Admin Control Panel icon
else {
	echo '<nav>
	<a href="#">
				<?php echo $pharmacist["first_name"] . " " . $pharmacist["last_name"]; ?>
			</a>
		 <a href="pharmacist.php">
		<i class="fas fa-home fa-2x"></i>
	</a>			
	  <a href="includes/handlers/logout.php">
		<i class="fas fa-power-off fa-2x"></i>
	  </a>	
</nav>';

}


?>

<body>
	<div class="container" style="position: relative; top: 100px; width: 100%; height: 800px; overflow-y: scroll;">
		<div class="content">
				<div id="myModal" class="modal">
					<div class="modal-content">
					    <div class="modal-header">
					      <span style="display: none;" class="close">&times;</span>
					      <h2>Schedule blood work exam</h2>
					    </div>
					    <div class="modal-body">
					      <form method="POST">
					      	<input type="email" name="email" placeholder="Enter email">
					      	<label for="a_date">Preferred date</label>
					      	<label for="exam">Test</label>
					      	<select id="exam" name="bloodTest">
					      		<option value="" disabled selected>Select blood test</option>
					      		<?php 
					      			$query = mysqli_query($con, "SELECT ELEMENT_CODE FROM blood_tests");
					      			$results = mysqli_fetch_array($query);
					      			while ($row = $query->fetch_assoc()) {
					      				echo "<option value=\"{$row['ELEMENT_CODE']}\">{$row['ELEMENT_CODE']}</option>";
					      			}
					      		?>
					      	</select>
					      	<input id="a_date" type="date" name="appointmentDate">
					      	<label for="a_time">Appointment time</label>
					      	<input id="a_time" type="time" name="appointmentTime">
					      	<button type="submit" name="bookSchedule">Schedule</button>
					      </form>
					    </div>
					    <div class="modal-footer">
					      <h3>Noobs</h3>
					    </div>
					  </div>
			</div>
			<div class="prescribe">
				<h1 style="text-align: left; padding: 10px; color: #222; ">
					Create new prescription
				</h1>
				<iframe src="pickup.php" id="frame" name="content2" style="display: none;"></iframe>
				<form action="pickup.php" id="createPrescription" method="POST" target="content2">
					<input id="username" type="email" name="email" placeholder="Enter patient' email">
					<select onchange="getRestrictionLevel()" id="medication" name="medicine" value="">
						 <option value="" disabled selected>Select medicine</option>
						<?php 
						    $query = mysqli_query($con, "SELECT MEDICATION,BLOOD_WORK_RESTRICTION_LEVEL FROM medication");
						    while ($row = $query->fetch_assoc())
						    {
						        $restriction = strval($row['BLOOD_WORK_RESTRICTION_LEVEL']);
						        $value = $restriction.''.$row['MEDICATION'];
						        echo "<option value=\"{$value}\">{$row['MEDICATION']}</option>";
						    }
						?>
					</select>
					<label for="restrictions">Repeat Prescription</label>
					<select form="createPrescription" id="restrictions" name="repeat"></select>
				</form> 
				<div id="test" class="alert" style="display: none; padding: 20px; background-color: #f44336; color: white;">
				  <span class="closebtn" onclick="this.parentElement.style.display='none';" style="margin-left: 15px; color: white; font-weight: bold; float: right; font-size: 22px; line-height: 20px; cursor: pointer; transition: 0.3s;">&times;</span> 
				  <strong>Danger!</strong> A Blood test may be required for this medication
				</div>
				<form>
					<input form="createPrescription" id="testMed" style="font-size: 24px; background-color: #588c7e; border-radius: 5px; color: black; padding: 20px; border: none;" type="submit" name="verifyBlood" value="Verify blood work">
					<button form="createPrescription" name="insertPrescription" type="submit" id="create" style="font-size: 24px; background-color: #588c7e; border-radius: 5px; color: black; padding: 20px; border: none;">Create Prescription</button>
				</form>
			</div>
			<div class="prescribe">
				<h1 style="text-align: left; padding: 10px; color: #222;">
					Register Prescription Pickup
				</h1>
				<form id="registerPrescription" method="POST">
					<input placeholder="Enter patients email" type="email" name="email" id="p_name">
					<select id="medication" name="medicine" value="" onchange="verifyBloodWork()">
						 <option value="" disabled selected>Select medicine</option>
						<?php 
						    $sql = mysqli_query($con, "SELECT MEDICATION FROM medication");
						    while ($row = $sql->fetch_assoc()){
						        echo "<option value=\"{$row['MEDICATION']}\">{$row['MEDICATION']}</option>";
						    }
						?>
					</select>
					<div class="loader" name="load"></div>
					<span id="tick" style="font-size: 2em; color: green; display: none;"><i class="fas fa-check"></i></span>
				</form>
				<form>
					<button style="letter-spacing: 2px; top: -45px; border-radius: 5px;  font-size: 24px; background-color: #588c7e; color: black; padding: 20px; border: none;" name="subject" type="submit" form="registerPrescription">
						Prescribe
					</button>
					<button form="" id="book" style="display: none; font-size: 24px; background-color: #588c7e; color: black; padding: 20px; border: none;">Book schedule</button>
				</form>
			</div>
		</div>
	</div>
</body>


<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://code.jquery.com/jquery-migrate-1.4.1.min.js"></script>
<script type="text/javascript">
	function displayMedication($medicine){
		if ($medicine){
			var med = $medicine;
			document.getElementById("medication") = med;
		}
	}

    var bloodWork = document.getElementById("exam");

	function displayBloodWork($bloodWork){
		if ($bloodWork){
			bloodWork.value = $bloodWork;
			alert("We recommed the patient get tested for this prescription \n Test: " + $bloodWork);
		}
	}

	function displayEmail($email){
		document.getElementById("username").value = $email;
	}

	function displayRestriction($restriction){
		var i = parseInt($restriction);
		var value = i.toString();
		document.getElementById("restrictions").value = $value;
	}

	function getRestrictionLevel() {
		var value = document.getElementById("medication").value;
		var select = document.getElementById("restrictions");
		select.innerHTML = "";	
		var restriction = parseInt(value[0]);
		var option = document.createElement("option");
		for (var i = 0; i < restriction; i++){
			var option = document.createElement("option");
			var number = (i+1).toString();
		   	option.text = number;
		   	select.add(option);
		}
		document.getElementById('testMed').style.opacity = '1';
		document.getElementById('create').style.opacity = '0.5';
	}

	document.getElementById("create").style.opacity = '0.5';

	var modal = document.getElementById("myModal");

	var span = document.getElementsByClassName("close")[0];

	var button = document.getElementById("book");

	button.onclick = function() {
	 	modal.style.display = "block";
	}

	span.onclick = function() {
		modal.style.display = "none";
	}

	window.onclick = function(event) {
	  	if (event.target == modal) {
			modal.style.display = "none";
		}
	}

	$( window ).load(function() {
        var frm = $('#createPrescription');
        frm.submit(function (ev) {
            $.ajax({
                type: frm.attr('method'),
                url: frm.attr('action'),
                data: frm.serialize(),
                beforeSend: function() {
			        document.getElementById('testMed').style.opacity = '0.5';
			        document.getElementById('create').style.opacity = '1';
			    }
            });
        });
    });

    $( window ).load(function() {
        var frm = $('#registerPrescription');
        frm.submit(function (ev) {
            $.ajax({
                type: frm.attr('method'),
                url: frm.attr('action'),
                data: frm.serialize(),
                beforeSend: function() {
			    }
            });
        });
    });

    

</script>


<?php

if (isset($_POST['verifyBlood']) && !empty($_POST['medicine'])) 
{
	$medicine = substr($_POST['medicine'], 1);
	$query = "SELECT BLOOD_WORK_RESTRICTION_LEVEL,ELEMENT_CODE FROM medication,blood_tests WHERE medication.ID = blood_tests.ID AND MEDICATION='".$medicine."';";
	$select = mysqli_query($con,$query);
	$results = mysqli_fetch_array($select);
	$bloodWork = json_encode($results['ELEMENT_CODE']);
	
	$restriction = $results['BLOOD_WORK_RESTRICTION_LEVEL'];
	if ($restriction > 0){
		echo "<script>displayBloodWork(".$bloodWork.")</script>";
	}
	else {
		echo "<script>alert('ok!')</script>";
	}
}

if (isset($_POST['insertPrescription']))
{
	$medicine = substr($_POST['medicine'], 1);
	$username = $_POST['email'];
	$repeat = $_POST['repeat'];

	$query = "SELECT id FROM medication WHERE MEDICATION='$medicine';";
	$select = mysqli_query($con,$query);
	$medicine_id = mysqli_fetch_array($select);

	$query = "SELECT id FROM patient WHERE email='$username';";
	$select = mysqli_query($con,$query);
	$userId = mysqli_fetch_array($select);

	$patientquery = mysqli_query($con, "SELECT * FROM patient WHERE email='$username'");
	$patientarray = mysqli_fetch_array($patientquery);
	$fname = $patientarray['first_name'];
	$lname = $patientarray['last_name'];

	$pharmacistfname = $pharmacist['first_name'];
	$pharmacistlname = $pharmacist['last_name'];

	if($repeat < 1){
		$pickupDate = "Not Required";
		$repeat = "No repeated dosage for this medication";
	}
	else {
		$pickupDate = date("Y-m-d", strtotime("+30 days"));
	}
	
	if ($userId != 0){
		$query = "SELECT prescription_id FROM prescriptions WHERE medication_id='$medicine_id' AND patient_id='$userId'";
		$select = mysqli_query($con,$query);
		$prescription_id = mysqli_fetch_array($select);
		/*if ($prescription_id == 0){
			if ($repeat != 0){
				$repeat = $repeat - 1;
			}*/
			$query = "INSERT INTO prescriptions (prescription_id,patient_id,medication_id,repeat_prescription) VALUES (null,".$userId['id'].",".$medicine_id['id'].",".$repeat.");";
			mysqli_query($con,$query);
			echo "<script>alert('Prescription created successfully')</script>";

			$mail = new PHPMailer(true);

	try {
	    //Server settings
	   // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
	    $mail->isSMTP();                                            // Send using SMTP
	    $mail->Host       = 'smtp.dreamhost.com';                    // Set the SMTP server to send through
	    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
	    $mail->Username   = 'noobs@shake-chat.com';                     // SMTP username
	    $mail->Password   = 'prescriptionst0121709';                               // SMTP password
	    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
	    $mail->Port       = 587;                                    // TCP port to connect to

	    //Recipients
	    $mail->setFrom('noobs@shake-chat.com', 'Noobs Prescription');
	    $mail->addAddress($username);     // Add a recipient
	   $mail->smtpConnect(
    	array(
        	"ssl" => array(
            "verify_peer" => false,
            "verify_peer_name" => false,
            "allow_self_signed" => true
        			)
   	 			)
			);

	    // Content

	    $mail->isHTML(true);                                  // Set email format to HTML
	    $mail->Subject = 'Prescription Details';
	    $mail->Body    = "<b><h1 style='font-family:Bellota-BoldItalic; color:#ff8800'><center>Noobs Prescription</center></h1></b>
	    <br>
	    <h3>Dear $fname $lname,</h3>
	    <br>
	    <h3 style='font-family:emoji'>The following are your prescription details:</h3><hr>
	    <nobr><h2 style='font-family:Bellota-LightItalic'><b>Prescribed Medication:</b></h2></nobr> <nobr><h3 style='color: red'>$medicine</h3></nobr>
	    <h2 style='font-family:Bellota-LightItalic'><b>Monthly Repeats:</b></h2><h3 style='color: red'>$repeat</h3>
	    <h2 style='font-family:Bellota-LightItalic'><b>Next Pickup Date:</b></h2><h3 style='color: red'>$pickupDate</h3>
	    <hr>
	     <h3 style='color: #B2ABB2; font-family: Arial'>Signed by: $pharmacistfname $pharmacistlname</h3>

	    <h5><b>DISCLAIMER:</b> If you are not the mentioned individual in this message, please ignore the email.</h5>";


	    $mail->send();
	} catch (Exception $e) {
	    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
	}
	exit(); //if the form is submitted, ensures users dont resubmit it again.

}
		
	}



if (isset($_POST['subject']) && !empty($_POST['medicine']) && !empty($_POST['email']))
{
	$medicine = $_POST['medicine'];
	$username = $_POST['email'];

	$query = "SELECT id FROM medication WHERE MEDICATION='$medicine';";
	$select = mysqli_query($con,$query);
	$medicine_id = mysqli_fetch_array($select);

	$query = "SELECT prescriptions.prescription_id,prescriptions.medication_id,prescriptions.patient_id,prescriptions.repeat_prescription FROM prescriptions INNER JOIN patient ON prescriptions.patient_id = patient.id INNER JOIN medication ON medication.ID = prescriptions.medication_id WHERE patient.email = '$username' AND prescriptions.medication_id = '".$medicine_id['id']."';";
	$select = mysqli_query($con,$query);
	$prescription = mysqli_fetch_array($select);

	if ($prescription['prescription_id'] > 0 && $prescription['repeat_prescription'] > 0){
		$query = "UPDATE prescriptions SET repeat_prescription=(repeat_prescription - 1) WHERE prescription_id=".$prescription['prescription_id'].";";
		mysqli_query($con,$query);
		echo "<script>alert('Prescription registered successfully!')</script>";
	}
	else if ($prescription['prescription_id'] > 0 && $prescription['repeat_prescription'] < 1){
			$query = "DELETE FROM prescriptions WHERE prescription_id=".$prescription['prescription_id'].";";
			mysqli_query($con,$query);
			echo "<script>alert('Prescription registered! Please advise: This was the last repeat prescription for the patient.')</script>";
		}
}

?>

