<?php 
include("includes/header.php");

//If the user is not an administrator, send them back to the login page
$query = mysqli_query($con, "SELECT * FROM pharmacist WHERE email='$pharmacistLoggedIn'");
$row = mysqli_fetch_array($query);


$isAdmin = $row['admin'];

//if the user is an administrator, show them the Admin Control Panel icon
if($isAdmin == 'yes'){
	echo '<nav>
			<a href="pharmacist.php">
		<i class="fas fa-home fa-2x"></i>
		</a>	
	 <a href="admin.php">
	  	<i class="fas fa-user-shield fa-2x"></i>
	  </a>			
	  <a href="includes/handlers/logout.php">
		<i class="fas fa-power-off fa-2x"></i>
	  </a>
</nav>';
}
//if the user is not an administrator, hide the Admin Control Panel icon
else {
	echo '<nav>
	<a href="#">
				<?php echo $row["first_name"] . " " . $row["last_name"]; ?>
			</a>
		 <a href="pharmacist.php">
		<i class="fas fa-home fa-2x"></i>
	</a>			
	  <a href="includes/handlers/logout.php">
		<i class="fas fa-power-off fa-2x"></i>
	  </a>	
</nav>';

}



?>

<!DOCTYPE html>
<html>
<head>
	<title>Noobs Prescription</title>
</head>
<body>

<div class='results' id='results'>

	
	<?php 
		$query = mysqli_query($con, "SELECT * FROM patient ORDER BY id ASC");
		$row = mysqli_fetch_array($query);
		$num_pharmacists = mysqli_num_rows($query);
		if(mysqli_num_rows($query) == 0){
			echo "<h1><span style='color:black;'>There are no patients registered within the database<br></span></h1>";
		}
		else if(mysqli_num_rows($query) == 1){
			echo "<div class='pharmacist_number'><h3><span style='color:black;'>$num_pharmacists registered patients</span></h3>
				</div>";
		}
		else {
			echo "<div class='pharmacist_number'><h3><span style='color:black;'>$num_pharmacists registered patients</span></h3>
				</div>";
		}
		?>
		<div class='result_body'>
		 <table class='patient-table'>
	 	<thead>	
    		<tr>
     			<th>ID</th>
     			<th>Name</th>
     			<th>Email</th>
     			<th>Age</th>
     			<th>Gender</th>
     			<th>BloodType</th>
    		</tr>
    	</thead>		


		<tbody>
		<?php
		foreach ($query as $row){
			$patientid = $row['id'];
			$first_name = $row['first_name'];
			$last_name = $row['last_name'];
			$email2 = $row['email'];
			$age = $row['age']; 
			$gender = $row['gender'];
			$blood = $row['blood_type'];?>
			
				
				<tr>
				<td><?=$patientid?></td>
     			<td><?=$first_name. " " .$last_name?></td>
     			<td><?=$email2?></td>
     			<td><?=$age?></td>
     			<td><?=$gender?></td>
     			<td><?=$blood?></td>
     			</tr>
			
			
	<?php	}  ?>
			</tbody>
     		</table>

	</div>
</div>

	</body>
</html>
