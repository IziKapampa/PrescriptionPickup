<?php 
require 'config/config.php';
include("includes/handlers/register_handler.php");

//Ensuring that the user successfully logged in & ensuring that the user did not get signed out.
if(isset($_SESSION['email'])){
	$pharmacistLoggedIn = $_SESSION['email'];
	$pharmacist_details_query = mysqli_query($con, "SELECT * FROM pharmacist WHERE email='$pharmacistLoggedIn'");
	$pharmacist = mysqli_fetch_array($pharmacist_details_query);
}

else {
	header("Location: register.php");
	exit();
}



?>

<html>
<head>
	<!-- Javascript -->
	<script src="https://kit.fontawesome.com/23551875e4.js" crossorigin="anonymous"></script>
	<script src="Assets/js/bootstrap.js"></script>
	<script src="Assets/js/project.js"></script>
	<script src="Assets/js/bootbox.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://unpkg.com/read-excel-file@4.x/bundle/read-excel-file.min.js"></script>	
	<!--CSS-->
	<link rel="stylesheet" type="text/css" href="Assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="Assets/css/bootstrap.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
</head>
<body>

<div class="top_bar">
		<div class="logo">
			<a href="index.php">Noobs Prescription</a>
		</div>


<!-- <nav>
	<div class="options">
		<span><i class="fa fa-bars"></i></span>
		<span><i class="far fa-sticky-note"></i></span>
	</div>
	<h1 class="logo">Logo</h1>
</nav>
 -->
		

</body>
</html>